package com.gigih.proj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
